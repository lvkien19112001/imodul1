#!bin/bash

sudo chmod -r /$HOME/password.txt
